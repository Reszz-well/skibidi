

__MODULE__ = "Memify"
__HELP__ = """
Bantuan Untuk Memify


• Perintah: <code>{0}mmf</code> [text]
• Penjelasan: Balas Ke Sticker atau Foto akan Di ubah menjadi sticker teks meme yang di tentukan.
"""
