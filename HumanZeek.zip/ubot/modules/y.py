
__MODULE__ = "YoutubeDL"
__HELP__ = """
Bantuan Untuk YoutubeDL

• Perintah: <code>{0}song</code> [song title]
• Penjelasan: Untuk mendownload music yang diinginkan.

• Perintah: <code>{0}video</code> [video title]
• Penjelasan: Untuk mendownload video yang diinginkan.
"""
