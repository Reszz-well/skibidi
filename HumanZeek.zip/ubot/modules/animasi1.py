

__MODULE__ = "Fun"
__HELP__ = """
Bantuan Untuk Fun

• Perintah:  <code>{0}dino or {0}babi</code>
• Penjelasan:  Coba sendiri.

• Perintah: <code>{0}santet or {0}gabut</code>
• Penjelasan: Coba sendiri.

• Perintah: <code>{0}syg or {0}hack</code>
• Penjelasan: Coba sendiri.

• Perintah:  <code>{0}hug or {0}bomb</code>
• Penjelasan:  Coba sendiri.

• Perintah:  <code>{0}brain or {0}kntl</code>
• Penjelasan:  Coba sendiri.

• Perintah:  <code>{0}penis or {0}hmm</code>
• Penjelasan:  Coba sendiri.

• Perintah: <code>{0}tembak or {0}bundir</code>
• Penjelasan: Coba sendiri.

• Perintah: <code>{0}heli or {0}y</code>
• Penjelasan: Coba sendiri.

• Perintah:  <code>{0}love or {0}awk</code>
• Penjelasan:  Coba sendiri.

• Perintah:  <code>{0}nah or {0}ajg</code>
• Penjelasan:  Coba sendiri.

• Perintah: <code>{0}loveyou or {0}call</code>
• Penjelasan: Coba sendiri.

• Perintah: <code>{0}kill or {0}wtf</code>
• Penjelasan: Coba sendiri.

• Perintah: <code>{0}ding or {0}hypo</code>
• Penjelasan: Coba sendiri.

• Perintah: <code>{0}gang or {0}charging</code>
• Penjelasan: Coba sendiri.

• Perintah: <code>{0}kocok or {0}tank</code>
• Penjelasan: Coba sendiri.
"""
