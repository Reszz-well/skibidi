python3 test.py & python3 -m ubot
