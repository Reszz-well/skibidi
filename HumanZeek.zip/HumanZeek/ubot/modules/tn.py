

__MODULE__ = "Tiny"
__HELP__ = """
Bantuan Untuk Tiny

• Perintah: <code>{0}tiny</code> [reply to sticker]
• Penjelasan: Untuk merubah sticker menjadi kecil.
"""
