__MODULE__ = "Prefix"
__HELP__ = """
Bantuan Untuk Prefix

• Perintah: <code>{0}prefix</code> [trigger]
• Penjelasan: Untuk mengatur handler userbot anda.
"""
