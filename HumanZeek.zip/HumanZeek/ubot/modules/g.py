

__MODULE__ = "Global"
__HELP__ = """
Bantuan Untuk Global

• Perintah: <code>{0}gban</code> [user_id/username/reply to user]
• Penjelasan: Untuk banned user dari semua group chat.

• Perintah: <code>{0}ungban</code> [user_id/username/reply to user]
• Penjelasan: Untuk unbanned user dari semua group chat.

• Perintah: <code>{0}listgban</code>
• Penjelasan: Untuk melihat daftar pengguna yang anda gban.
"""
